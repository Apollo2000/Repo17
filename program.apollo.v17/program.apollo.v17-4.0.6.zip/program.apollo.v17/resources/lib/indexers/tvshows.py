# -*- coding: utf-8 -*-
from requests import get
from resources.lib.modules import control
import sys,re,json,urllib,urlparse

class tvshows:
	def __init__(self):
		self.list = []
	
	def search(self):
		try:
			control.idle()

			t = control.lang(32010).encode('utf-8')
			k = control.keyboard('', t) ; k.doModal()
			q = k.getText() if k.isConfirmed() else None

			if (q == None or q == ''): return

			headers = {'Content-Type': 'application/json', 'Accept': 'application/json', 'Authorization': 'Bearer '+control.addon().getSetting('token')}
			response = get(control.myaddon_link+'info/tvshow/search/%s'%q, headers=headers)
			data = json.loads(response.text)
			if "data" not in data:
				print "### ERROR Load TV Show Category JSON: {0}".format(category_id)
				return
			self.tvshowItems(data['data'])
		except:
			return
	
	def tvshowItems(self,tvshows):
		for tvshow in tvshows:
			meta = tvshow["meta"]
			
			try:
				imdb = tvshow['imdb_id']
				tvdb = tvshow['tvdb_id']
				
				userLang = control.apiLanguage(control.lang)["id"]
				
				title = 0
				plot = 0
				
				if userLang!="en":
					try:
						langData = control.getLangMeta("tvshow", imdb, tvdb, userLang)
						title = langData['SeriesName']
						plot = langData['Overview']
					except:
						pass

				if title==0:
					title = tvshow['title']
				
				if plot==0:
					if 'plot' in meta:
						plot = meta['plot']
					else:
						plot = 0

				title = title.encode('utf-8')
				plot = plot.encode('utf-8')

				year = tvshow['year']

				if 'poster' in meta:
					poster = meta['poster']
				else:
					poster = 0

				if 'fanart' in meta:
					fanart = meta['fanart']
				else:
					fanart = 0

				if 'released' in meta:
					premiered = meta['released'][0:10]
				else:
					premiered = '0'
				
				if 'genres' in meta:
					genre = meta['genres']
				else:
					genre = 0
				genre = genre.encode('utf-8')
				
				if 'rank' in meta:
					rating = meta['rank']
				else:
					rating = 0

				if 'votes' in meta:
					votes = meta['votes']
				else:
					votes = 0

				if 'director' in meta:
					director = meta['director']
				else:
					director = 0
				director = director.replace(', ', ' / ')
				director = director.encode('utf-8')
				
				if 'writer' in meta:
					writer = meta['writer']
				else:
					writer = 0
				writer = writer.replace(', ', ' / ')
				writer = writer.encode('utf-8')
				
				self.list.append({'imdb': imdb,'title': title, 'year': year, 'code': imdb, 'tvdb': tvdb, 'poster': poster, 'banner': '', 'fanart': fanart, 'premiered': premiered, 'studio': '', 'genre': genre, 'rating': rating, 'votes': votes, 'director': director, 'writer': writer, 'plot': plot})
			except: 
				print "####### ERROR JSON Rec: {0}".format(tvshow)
				pass
	
		self.tvshowDirectory(self.list)
		return self.list
	
	
	def tvshowsCategory(self, category_id):
		try:
			headers = {'Content-Type': 'application/json', 'Accept': 'application/json', 'Authorization': 'Bearer '+control.addon().getSetting('token')}
			response = get(control.myaddon_link+'info/tvshows/categories/%s'%category_id, headers=headers)
			data = json.loads(response.text)
			if "data" not in data:
				print "### ERROR Load TV Shows Category JSON: {0}".format(category_id)
				return
			
			self.tvshowItems(data['data'][0]["infos"])
		except:
			return []
			pass

	def tvshowDirectory(self, items):
		if items == None or len(items) == 0: control.idle() ; sys.exit()

		sysaddon = sys.argv[0]
		syshandle = int(sys.argv[1])
		addonPoster, addonBanner = control.addonPoster(), control.addonBanner()
		addonFanart, settingFanart = control.addonFanart(), control.setting('fanart')

		for i in items:
			try:
				label = i['title']
				systitle = sysname = urllib.quote_plus(i['title'])
				sysimage = urllib.quote_plus(i['poster'])
				imdb, tvdb, year = i['imdb'], i['tvdb'], i['year']

				meta = dict((k,v) for k, v in i.iteritems() if not v == '0')
				meta.update({'mediatype': 'tvshow'})
				meta.update({'trailer': '%s?action=trailer&name=%s' % (sysaddon, sysname)})
				if not 'duration' in i: meta.update({'duration': '60'})
				elif i['duration'] == '0': meta.update({'duration': '60'})
				try: meta.update({'duration': str(int(meta['duration']) * 60)})
				except: pass
				try: meta.update({'genre': cleangenre.lang(meta['genre'], self.lang)})
				except: pass

				url = '%s?action=tvshowsSeasons&imdb=%s&title=%s' % (sysaddon, imdb, systitle)

				cm = []

				item = control.item(label=label)

				art = {}

				if 'poster' in i and not i['poster'] == '0':
					art.update({'icon': i['poster'], 'thumb': i['poster'], 'poster': i['poster']})
				else:
					art.update({'icon': addonPoster, 'thumb': addonPoster, 'poster': addonPoster})

				if 'banner' in i and not i['banner'] == '0':
					art.update({'banner': i['banner']})
				elif 'fanart' in i and not i['fanart'] == '0':
					art.update({'banner': i['fanart']})
				else:
					art.update({'banner': addonBanner})

				if 'clearlogo' in i and not i['clearlogo'] == '0':
					art.update({'clearlogo': i['clearlogo']})

				if 'clearart' in i and not i['clearart'] == '0':
					art.update({'clearart': i['clearart']})

				if settingFanart == 'true' and 'fanart' in i and not i['fanart'] == '0':
					item.setProperty('Fanart_Image', i['fanart'])
				elif not addonFanart == None:
					item.setProperty('Fanart_Image', addonFanart)

				item.setArt(art)
				item.addContextMenuItems(cm)
				item.setInfo(type='Video', infoLabels = meta)

				control.addItem(handle=syshandle, url=url, listitem=item, isFolder=True)
			except:
				pass

		control.content(syshandle, 'tvshows')
		control.directory(syshandle, cacheToDisc=True)
