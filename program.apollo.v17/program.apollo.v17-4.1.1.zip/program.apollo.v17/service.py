import xbmc, xbmcgui, os, json, requests , re, urllib
import pvr, wall
from resources.lib.modules import control

def UpdateDomain():
	try:
		response = requests.get("https://raw.githubusercontent.com/Apollo2000/Repo/master/domainv2.txt", verify=False)
		data = json.loads(response.text)
		control.addon().setSetting('api', 'https://'+data['result']+'/api/')
	except: 
		pass

def versiontuple(v):
    return tuple(map(int, (v.split("."))))

def CheckAddonUpdate():
	try:
		folder = xbmc.translatePath(os.path.join('special://home','addons','repository.apollo'))
		if not os.path.isdir(folder):
			os.makedirs(folder)
			xml_file = xbmc.translatePath(os.path.join('special://home','addons','repository.apollo','addon.xml'))
			icon_file = xbmc.translatePath(os.path.join('special://home','addons','repository.apollo','icon.png'))
			urllib.urlretrieve ("https://raw.githubusercontent.com/Apollo2000/Repo18/master/repository.apollo/addon.xml", xml_file)
			urllib.urlretrieve ("https://raw.githubusercontent.com/Apollo2000/Repo18/master/repository.apollo/icon.png", icon_file)
	except: pass
	
	if control.addon().getSetting('firstRun')=="true":
		if control.addon().getSetting('email')== "":
			i = control.dialog.yesno("Apollo Group","Are you a member ?")
			if i == 1:
				email = control.dialog.input('Enter Member Email', type=xbmcgui.INPUT_ALPHANUM)
				control.addon().setSetting('email', str(email))
				password = control.dialog.input('Enter Member Password', type=xbmcgui.INPUT_ALPHANUM)
				control.addon().setSetting('password', str(password))
			else:
				control.dialog.ok('Apollo Group',"Get membership at website ApolloGroup.tv")
		control.addon().setSetting('firstRun', 'false')
		xbmc.sleep(10)

	LocalVersion = control.addon().getAddonInfo('version')
	try:
		if control.addon().getAddonInfo('id')=="program.apollo":
			response = requests.get("https://raw.githubusercontent.com/Apollo2000/Repo18/master/program.apollo/addon.xml")
		elif control.addon().getAddonInfo('id')=="program.apollo.v17":
			response = requests.get("https://raw.githubusercontent.com/Apollo2000/Repo17/master/program.apollo.v17/addon.xml")
		match = re.search (r'version="(\d\.\d\.\d)"', response.text,re.M|re.I)
	except: 
		pass

	if not match:
		return
	RemoteVersion = match.groups()[0]

	STRversion = str(LocalVersion)+"/"+str(RemoteVersion)
	if not control.addon().getSetting('version')==str(STRversion):
		control.addon().setSetting('version', str(STRversion))

	if versiontuple(RemoteVersion) > versiontuple(LocalVersion):
		xbmc.executebuiltin('Notification(Apollo Group,"Please wait, Updating Addon to {0}.", 5000,{1})'.format(RemoteVersion,os.path.join(control.addonPath ,"icon.png")))
		xbmc.executebuiltin("XBMC.UpdateAddonRepos()")
		sys.exit(1)

if control.addon().getAddonInfo('id')=="program.apollo" or control.addon().getAddonInfo('id')=="program.apollo.v17":
	UpdateDomain()
	CheckAddonUpdate()

xbmc.sleep(10000)
xbmc.executebuiltin("RunPlugin(plugin://%s)" % (control.addon().getAddonInfo('id')+"/?action=login&param=1"));
xbmc.sleep(10000)
pvr.runPVR()
xbmc.sleep(60000)
wall.runWall()

command = "RunPlugin(plugin://%s)" % control.addon().getAddonInfo('id')+"/service.py"
xbmc.executebuiltin("AlarmClock(MyAddonWall,%s,360,false,true)" % command )